package com.yourcompany.smartchat.manager;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.graphics.Color;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.yourcompany.smartchat.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SmartFabManager {
    private Context context;
    private FloatingActionButton fabSmart;
    private LinearLayout contextMenu;
    private boolean isMenuVisible = false;
    private SmartFabListener listener;

    public interface SmartFabListener {
        void onGenerateCodeRequest();
        void onDebugCodeRequest();
        void onExplainCodeRequest();
        void onClaudeCodeRequest();
        void onSmartHelpRequest(String context);
    }

    public SmartFabManager(Context context, View rootView, SmartFabListener listener) {
        this.context = context;
        this.listener = listener;
        initializeViews(rootView);
        setupFabBehavior();
    }

    private void initializeViews(View rootView) {
        fabSmart = rootView.findViewById(R.id.fabSmart);
        contextMenu = rootView.findViewById(R.id.contextMenu);

        Button btnGenerateCode = rootView.findViewById(R.id.btnGenerateCode);
        Button btnDebugCode = rootView.findViewById(R.id.btnDebugCode);
        Button btnExplainCode = rootView.findViewById(R.id.btnExplainCode);
        Button btnClaudeCode = rootView.findViewById(R.id.btnClaudeCode);

        // إعداد مستمعي النقر للأزرار
        btnGenerateCode.setOnClickListener(v -> {
            hideContextMenu();
            if (listener != null) {
                listener.onGenerateCodeRequest();
            }
        });

        btnDebugCode.setOnClickListener(v -> {
            hideContextMenu();
            if (listener != null) {
                listener.onDebugCodeRequest();
            }
        });

        btnExplainCode.setOnClickListener(v -> {
            hideContextMenu();
            if (listener != null) {
                listener.onExplainCodeRequest();
            }
        });

        btnClaudeCode.setOnClickListener(v -> {
            hideContextMenu();
            if (listener != null) {
                listener.onClaudeCodeRequest();
            }
        });
    }

    private void setupFabBehavior() {
        // النقر الطويل لإظهار القائمة
        fabSmart.setOnLongClickListener(v -> {
            showContextMenu();
            return true;
        });

        // النقر العادي للمساعدة الذكية
        fabSmart.setOnClickListener(v -> {
            if (isMenuVisible) {
                hideContextMenu();
            } else {
                showSmartAssistant();
            }
        });

        setupDraggableFab();
    }

    private void setupDraggableFab() {
        fabSmart.setOnTouchListener(new View.OnTouchListener() {
            private float dX, dY;
            private int lastAction;

            @Override
            public boolean onTouch(View view, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = view.getX() - event.getRawX();
                        dY = view.getY() - event.getRawY();
                        lastAction = MotionEvent.ACTION_DOWN;
                        break;

                    case MotionEvent.ACTION_MOVE:
                        view.setY(event.getRawY() + dY);
                        view.setX(event.getRawX() + dX);
                        lastAction = MotionEvent.ACTION_MOVE;
                        break;

                    case MotionEvent.ACTION_UP:
                        if (lastAction == MotionEvent.ACTION_DOWN) {
                            if (isMenuVisible) {
                                hideContextMenu();
                            } else {
                                showSmartAssistant();
                            }
                        }
                        break;

                    default:
                        return false;
                }
                return true;
            }
        });
    }

    private void showContextMenu() {
        isMenuVisible = true;
        contextMenu.setVisibility(View.VISIBLE);
        
        contextMenu.setAlpha(0f);
        contextMenu.animate()
                .alpha(1f)
                .setDuration(300)
                .setListener(null);
        
        fabSmart.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#F56565")));
    }

    private void hideContextMenu() {
        isMenuVisible = false;
        
        contextMenu.animate()
                .alpha(0f)
                .setDuration(300)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        contextMenu.setVisibility(View.GONE);
                    }
                });
        
        fabSmart.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#8B5CF6")));
    }

    private void showSmartAssistant() {
        String context = analyzeCurrentContext();
        if (listener != null) {
            listener.onSmartHelpRequest(context);
        }
    }

    private String analyzeCurrentContext() {
        StringBuilder context = new StringBuilder();
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        context.append("الوقت: ").append(time).append("\n");
        context.append("الحالة: جاهز للمساعدة\n");
        context.append("الإمكانيات: إنشاء مشاريع، كتابة أكواد، تصحيح أخطاء، شرح مفاهيم");
        return context.toString();
    }

    public void updateFabContext(String contextType) {
        int color = Color.parseColor("#8B5CF6");
        switch (contextType) {
            case "coding":
                color = Color.parseColor("#4CAF50");
                break;
            case "debugging":
                color = Color.parseColor("#FF9800");
                break;
            case "explaining":
                color = Color.parseColor("#9C27B0");
                break;
            case "claude":
                color = Color.parseColor("#F56565");
                break;
        }
        fabSmart.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
    }

    public void show() {
        fabSmart.setVisibility(View.VISIBLE);
    }

    public void hide() {
        fabSmart.setVisibility(View.GONE);
        hideContextMenu();
    }
    
    public void toggleContextMenu() {
        if (isMenuVisible) {
            hideContextMenu();
        } else {
            showContextMenu();
        }
    }
    
    public boolean isMenuVisible() {
        return isMenuVisible;
    }
}