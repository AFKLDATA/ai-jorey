package com.yourcompany.smartchat.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.yourcompany.smartchat.R;
import com.yourcompany.smartchat.model.ChatMessage;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    
    private static final int TYPE_USER = 1;
    private static final int TYPE_BOT = 2;
    
    private List<ChatMessage> messageList;
    private OnMessageActionListener actionListener;

    public interface OnMessageActionListener {
        void onCopyMessage(String message);
        void onShareMessage(String message);
        void onSaveMessage(String message);
    }

    public ChatAdapter(List<ChatMessage> messageList) {
        this.messageList = messageList;
    }

    public ChatAdapter(List<ChatMessage> messageList, OnMessageActionListener actionListener) {
        this.messageList = messageList;
        this.actionListener = actionListener;
    }

    public void setMessages(List<ChatMessage> messages) {
        this.messageList = messages;
        notifyDataSetChanged();
    }

    public void addMessage(ChatMessage message) {
        messageList.add(message);
        notifyItemInserted(messageList.size() - 1);
    }

    public void clearMessages() {
        messageList.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.message_item, parent, false);
        
        if (viewType == TYPE_USER) {
            return new UserMessageViewHolder(view);
        } else {
            return new BotMessageViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatMessage message = messageList.get(position);
        
        if (holder instanceof UserMessageViewHolder) {
            ((UserMessageViewHolder) holder).bind(message);
        } else if (holder instanceof BotMessageViewHolder) {
            ((BotMessageViewHolder) holder).bind(message, actionListener);
        }
    }

    @Override
    public int getItemCount() {
        return messageList.size();
    }

    @Override
    public int getItemViewType(int position) {
        return messageList.get(position).isUser() ? TYPE_USER : TYPE_BOT;
    }

    static class UserMessageViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout userMessageLayout;
        private TextView userMessageText;
        private TextView userTimestamp;

        public UserMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            userMessageLayout = itemView.findViewById(R.id.userMessageLayout);
            userMessageText = itemView.findViewById(R.id.userMessageText);
            userTimestamp = itemView.findViewById(R.id.userTimestamp);
        }

        public void bind(ChatMessage message) {
            userMessageLayout.setVisibility(View.VISIBLE);
            userMessageText.setText(message.getMessage());
            
            // تنسيق الوقت
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            String time = sdf.format(message.getTimestamp());
            userTimestamp.setText(time);
        }
    }

    static class BotMessageViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout botMessageLayout;
        private TextView botMessageText;
        private TextView botTimestamp;
        private Button copyButton;
        private Button shareButton;
        private Button saveButton;

        public BotMessageViewHolder(@NonNull View itemView) {
            super(itemView);
            botMessageLayout = itemView.findViewById(R.id.botMessageLayout);
            botMessageText = itemView.findViewById(R.id.botMessageText);
            botTimestamp = itemView.findViewById(R.id.botTimestamp);
            copyButton = itemView.findViewById(R.id.copyButton);
            shareButton = itemView.findViewById(R.id.shareButton);
            saveButton = itemView.findViewById(R.id.saveButton);
        }

        public void bind(ChatMessage message, OnMessageActionListener actionListener) {
            botMessageLayout.setVisibility(View.VISIBLE);
            botMessageText.setText(message.getMessage());
            
            // تنسيق الوقت
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            String time = sdf.format(message.getTimestamp());
            botTimestamp.setText(time);

            // إعداد أزرار الإجراءات
            copyButton.setOnClickListener(v -> {
                if (actionListener != null) {
                    actionListener.onCopyMessage(message.getMessage());
                }
            });

            shareButton.setOnClickListener(v -> {
                if (actionListener != null) {
                    actionListener.onShareMessage(message.getMessage());
                }
            });

            saveButton.setOnClickListener(v -> {
                if (actionListener != null) {
                    actionListener.onSaveMessage(message.getMessage());
                }
            });

            // إظهار/إخفاء أزرار الإجراءات بناءً على نوع الرسالة
            if (message.getMessageType().equals("CODE") || message.getMessageType().equals("PROJECT")) {
                copyButton.setVisibility(View.VISIBLE);
                shareButton.setVisibility(View.VISIBLE);
                saveButton.setVisibility(View.VISIBLE);
            } else {
                copyButton.setVisibility(View.GONE);
                shareButton.setVisibility(View.GONE);
                saveButton.setVisibility(View.GONE);
            }
        }
    }
}