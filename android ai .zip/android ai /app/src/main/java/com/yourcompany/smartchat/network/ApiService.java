package com.yourcompany.smartchat.network;

import com.yourcompany.smartchat.model.ApiRequest;
import com.yourcompany.smartchat.model.ApiResponse;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface ApiService {
    @POST("v1/chat/completions")
    Call<ApiResponse> chatCompletion(
        @Header("Authorization") String authHeader,
        @Header("Content-Type") String contentType,
        @Body ApiRequest request
    );

    @POST("v1/completions")
    Call<ApiResponse> codeCompletion(
        @Header("Authorization") String authHeader,
        @Header("Content-Type") String contentType,
        @Body ApiRequest request
    );

    @POST("v1/engines/code-davinci-002/completions")
    Call<ApiResponse> codeGeneration(
        @Header("Authorization") String authHeader,
        @Header("Content-Type") String contentType,
        @Body ApiRequest request
    );
}