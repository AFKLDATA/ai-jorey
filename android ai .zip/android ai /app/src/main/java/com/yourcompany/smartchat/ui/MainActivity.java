package com.yourcompany.smartchat.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.yourcompany.smartchat.R;
import com.yourcompany.smartchat.adapter.ChatAdapter;
import com.yourcompany.smartchat.database.AppDatabase;
import com.yourcompany.smartchat.database.MessageDao;
import com.yourcompany.smartchat.manager.SmartFabManager;
import com.yourcompany.smartchat.manager.CommandExecutor;
import com.yourcompany.smartchat.manager.ClaudeCodeEngine;
import com.yourcompany.smartchat.model.ChatMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity implements 
        ChatAdapter.OnMessageActionListener,
        SmartFabManager.SmartFabListener {

    private RecyclerView chatRecyclerView;
    private EditText messageEditText;
    private ImageButton sendButton;
    private MaterialToolbar toolbar;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> messageList;
    private MessageDao messageDao;
    private SmartFabManager smartFabManager;
    private CommandExecutor commandExecutor;
    private ClaudeCodeEngine claudeCodeEngine;
    private ExecutorService executor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeDatabase();
        initializeComponents();
        initializeViews();
        setupRecyclerView();
        loadMessages();
        sendWelcomeMessage();
    }

    private void initializeDatabase() {
        AppDatabase db = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "smartchat-database").build();
        messageDao = db.messageDao();
    }

    private void initializeComponents() {
        commandExecutor = new CommandExecutor(this);
        claudeCodeEngine = new ClaudeCodeEngine(this);
        executor = Executors.newSingleThreadExecutor();
        
        messageList = new ArrayList<>();
        chatAdapter = new ChatAdapter(messageList, this);
        
        // Initialize SmartFab Manager
        smartFabManager = new SmartFabManager(this, findViewById(android.R.id.content), this);
        new Handler().postDelayed(() -> smartFabManager.show(), 1000);
    }

    private void initializeViews() {
        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(true);

        setupClickListeners();
    }

    private void setupClickListeners() {
        sendButton.setOnClickListener(v -> sendMessage());
        
        messageEditText.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                sendMessage();
                return true;
            }
            return false;
        });

        // إظهار القائمة الذكية عند النقر على حقل النص
        messageEditText.setOnClickListener(v -> {
            showAdvancedOptionsDialog();
        });
    }

    private void setupRecyclerView() {
        chatRecyclerView.setAdapter(chatAdapter);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void loadMessages() {
        executor.execute(() -> {
            List<ChatMessage> messages = messageDao.getAllMessages();
            runOnUiThread(() -> {
                messageList.clear();
                messageList.addAll(messages);
                chatAdapter.setMessages(messageList);
                scrollToBottom();
            });
        });
    }

    private void sendWelcomeMessage() {
        new Handler().postDelayed(() -> {
            String welcomeMessage = "🚀 **مرحباً بك في Claude Code Assistant!**\n\n" +
                    "**أنا مساعدك الذكي للبرمجة المتقدمة** 🤖\n\n" +
                    "**يمكنني مساعدتك في:**\n" +
                    "• 📝 كتابة الأكواد بلغات متعددة\n" +
                    "• 🔧 تصحيح الأخطاء البرمجية\n" +
                    "• 📚 شرح الكود والمفاهيم\n" +
                    "• 💡 إنشاء مشاريع كاملة\n" +
                    "• 🎯 تطبيقات ويب وموبايل\n" +
                    "• 🤖 أنظمة الذكاء الاصطناعي\n\n" +
                    "**استخدم الأيقونة الذكية ☝️ للوصول السريع!**\n" +
                    "**أو اكتب طلبك مباشرة...**";
            
            ChatMessage welcomeMsg = new ChatMessage(welcomeMessage, false);
            addMessage(welcomeMsg);
        }, 500);
    }

    private void sendMessage() {
        String messageText = messageEditText.getText().toString().trim();
        if (TextUtils.isEmpty(messageText)) {
            return;
        }

        // حفظ رسالة المستخدم
        ChatMessage userMessage = new ChatMessage(messageText, true);
        addMessage(userMessage);

        // مسح حقل النص
        messageEditText.setText("");

        // معالجة الرسالة بواسطة المدير الذكي
        processUserRequest(messageText);
    }

    private void processUserRequest(String userMessage) {
        // ✅ التنفيذ الفوري للأوامر المحلية
        executor.execute(() -> {
            String response = commandExecutor.executeCommand(userMessage);
            
            runOnUiThread(() -> {
                ChatMessage botMessage = new ChatMessage(response, false);
                addMessage(botMessage);
                scrollToBottom();
            });
        });
    }

    private void addMessage(ChatMessage message) {
        executor.execute(() -> {
            messageDao.insertMessage(message);
            runOnUiThread(() -> {
                messageList.add(message);
                chatAdapter.addMessage(message);
                scrollToBottom();
            });
        });
    }

    private void scrollToBottom() {
        if (messageList.size() > 0) {
            chatRecyclerView.scrollToPosition(messageList.size() - 1);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        
        if (id == R.id.menu_projects) {
            showProjectsDialog();
            return true;
        } else if (id == R.id.menu_clear) {
            clearConversation();
            return true;
        } else if (id == R.id.menu_about) {
            showAboutDialog();
            return true;
        }
        
        return super.onOptionsItemSelected(item);
    }

    private void showAdvancedOptionsDialog() {
        String[] options = {
            "🚀 إنشاء مشروع كامل (Claude Code)",
            "📝 توليد كود برمجي", 
            "🔧 تصحيح الأخطاء",
            "📚 شرح كود",
            "💡 أفكار مشاريع",
            "🎯 استشارة تقنية"
        };

        new MaterialAlertDialogBuilder(this)
            .setTitle("Claude Code - الخيارات المتقدمة")
            .setItems(options, (dialog, which) -> {
                handleAdvancedOption(options[which]);
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void handleAdvancedOption(String option) {
        if (option.contains("مشروع كامل")) {
            showProjectCreationDialog();
        } else if (option.contains("توليد كود")) {
            showCodeGenerationDialog();
        } else if (option.contains("تصحيح الأخطاء")) {
            showDebugDialog();
        } else if (option.contains("شرح كود")) {
            showExplanationDialog();
        } else if (option.contains("أفكار مشاريع")) {
            showProjectIdeas();
        } else if (option.contains("استشارة تقنية")) {
            showTechConsultation();
        }
    }

    private void showProjectCreationDialog() {
        EditText input = new EditText(this);
        input.setHint("صِف مشروعك (مثال: موقع تجارة إلكترونية، تطبيق مهام، إلخ)");
        input.setMinLines(3);
        
        new MaterialAlertDialogBuilder(this)
            .setTitle("🚀 مشروع Claude Code جديد")
            .setView(input)
            .setPositiveButton("إنشاء المشروع", (dialog, which) -> {
                String projectDescription = input.getText().toString();
                if (!projectDescription.isEmpty()) {
                    executeClaudeCode(projectDescription);
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void executeClaudeCode(String projectDescription) {
        String prompt = "Claude Code: " + projectDescription;
        ChatMessage userMessage = new ChatMessage(prompt, true);
        addMessage(userMessage);
        
        executor.execute(() -> {
            String response = commandExecutor.executeCommand(prompt);
            runOnUiThread(() -> {
                ChatMessage botMessage = new ChatMessage(response, false);
                addMessage(botMessage);
            });
        });
    }

    private void showCodeGenerationDialog() {
        String[] languages = {"Python", "Java", "Kotlin", "JavaScript", "C++", "Swift", "Dart", "TypeScript"};
        
        new MaterialAlertDialogBuilder(this)
            .setTitle("اختر لغة البرمجة")
            .setItems(languages, (dialog, which) -> showFunctionalityDialog(languages[which]))
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void showFunctionalityDialog(String language) {
        EditText input = new EditText(this);
        input.setHint("ماذا تريد أن أفعل؟ (مثال: دالة لحساب المجموع)");
        
        new MaterialAlertDialogBuilder(this)
            .setTitle("ماذا تريد في " + language + "?")
            .setView(input)
            .setPositiveButton("إنشاء", (dialog, which) -> {
                String functionality = input.getText().toString();
                if (!functionality.isEmpty()) {
                    String prompt = "اكتب كود " + language + " لـ: " + functionality;
                    ChatMessage userMessage = new ChatMessage(prompt, true);
                    addMessage(userMessage);
                    
                    executor.execute(() -> {
                        String response = commandExecutor.executeCommand(prompt);
                        runOnUiThread(() -> {
                            ChatMessage botMessage = new ChatMessage(response, false);
                            addMessage(botMessage);
                        });
                    });
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void showDebugDialog() {
        EditText input = new EditText(this);
        input.setHint("الصق الكود الذي تريد تصحيحه هنا...");
        input.setMinLines(5);
        
        new MaterialAlertDialogBuilder(this)
            .setTitle("تصحيح الكود")
            .setView(input)
            .setPositiveButton("تصحيح", (dialog, which) -> {
                String code = input.getText().toString();
                if (!code.isEmpty()) {
                    String prompt = "صحيح الكود التالي وأصلح الأخطاء:\n\n" + code;
                    ChatMessage userMessage = new ChatMessage(prompt, true);
                    addMessage(userMessage);
                    
                    executor.execute(() -> {
                        String response = commandExecutor.executeCommand(prompt);
                        runOnUiThread(() -> {
                            ChatMessage botMessage = new ChatMessage(response, false);
                            addMessage(botMessage);
                        });
                    });
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void showExplanationDialog() {
        EditText input = new EditText(this);
        input.setHint("الصق الكود الذي تريد شرحه هنا...");
        input.setMinLines(5);
        
        new MaterialAlertDialogBuilder(this)
            .setTitle("شرح الكود")
            .setView(input)
            .setPositiveButton("شرح", (dialog, which) -> {
                String code = input.getText().toString();
                if (!code.isEmpty()) {
                    String prompt = "اشرح الكود التالي بالتفصيل:\n\n" + code;
                    ChatMessage userMessage = new ChatMessage(prompt, true);
                    addMessage(userMessage);
                    
                    executor.execute(() -> {
                        String response = commandExecutor.executeCommand(prompt);
                        runOnUiThread(() -> {
                            ChatMessage botMessage = new ChatMessage(response, false);
                            addMessage(botMessage);
                        });
                    });
                }
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void showProjectIdeas() {
        String[] ideas = {
            "🌐 موقع محفظة شخصية",
            "📱 تطبيق إدارة المهام", 
            "🤖 بوت دردشة ذكي",
            "🎮 لعبة بسيطة",
            "📊 أداة تحليل بيانات",
            "🛒 نظام متجر إلكتروني"
        };
        
        new MaterialAlertDialogBuilder(this)
            .setTitle("💡 أفكار مشاريع مقترحة")
            .setItems(ideas, (dialog, which) -> {
                String prompt = "أريد إنشاء: " + ideas[which];
                ChatMessage userMessage = new ChatMessage(prompt, true);
                addMessage(userMessage);
                
                executor.execute(() -> {
                    String response = commandExecutor.executeCommand(prompt);
                    runOnUiThread(() -> {
                        ChatMessage botMessage = new ChatMessage(response, false);
                        addMessage(botMessage);
                    });
                });
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void showTechConsultation() {
        String[] topics = {
            "أفضل لغة برمجة للمشروع",
            "تصميم قاعدة البيانات",
            "هيكلة المشروع",
            "أفضل الممارسات",
            "تحسين الأداء",
            "الأمان والتوثيق"
        };
        
        new MaterialAlertDialogBuilder(this)
            .setTitle("🎯 استشارة تقنية")
            .setItems(topics, (dialog, which) -> {
                String prompt = "استشارة في: " + topics[which];
                ChatMessage userMessage = new ChatMessage(prompt, true);
                addMessage(userMessage);
                
                executor.execute(() -> {
                    String response = commandExecutor.executeCommand(prompt);
                    runOnUiThread(() -> {
                        ChatMessage botMessage = new ChatMessage(response, false);
                        addMessage(botMessage);
                    });
                });
            })
            .setNegativeButton("إلغاء", null)
            .show();
    }

    private void showProjectsDialog() {
        new MaterialAlertDialogBuilder(this)
            .setTitle("📂 إدارة المشاريع")
            .setMessage("**ميزات Claude Code:**\n\n" +
                       "• 🚀 إنشاء مشاريع كاملة\n" +
                       "• 📱 تطبيقات أندرويد و iOS\n" +
                       "• 🌐 مواقع ويب تفاعلية\n" +
                       "• 🤖 أنظمة ذكاء اصطناعي\n" +
                       "• 🔧 واجهات برمجة APIs\n\n" +
                       "**استخدم زر Claude Code لبدء مشروع جديد!**")
            .setPositiveButton("ممتاز!", null)
            .setNeutralButton("مشروع جديد", (dialog, which) -> {
                showProjectCreationDialog();
            })
            .show();
    }

    private void clearConversation() {
        new MaterialAlertDialogBuilder(this)
            .setTitle("مسح المحادثة")
            .setMessage("هل تريد مسح كل المحادثة؟")
            .setPositiveButton("نعم", (dialog, which) -> {
                executor.execute(() -> {
                    messageDao.deleteAllMessages();
                    runOnUiThread(() -> {
                        messageList.clear();
                        chatAdapter.setMessages(messageList);
                        sendWelcomeMessage();
                        Toast.makeText(this, "🗑️ تم مسح المحادثة", Toast.LENGTH_SHORT).show();
                    });
                });
            })
            .setNegativeButton("لا", null)
            .show();
    }

    private void showAboutDialog() {
        new MaterialAlertDialogBuilder(this)
            .setTitle("حول Claude Code")
            .setMessage("🚀 **Claude Code Assistant**\n\n" +
                       "• إصدار: 2.0\n" +
                       "• المطور: نظام Claude Code\n" +
                       "• الوصف: مساعد ذكي متقدم للبرمجة وإنشاء المشاريع\n\n" +
                       "⚡ **المميزات:**\n" +
                       "- إنشاء مشاريع كاملة\n" +
                       "- تنفيذ فوري للأوامر\n" +
                       "- دعم 10+ لغة برمجة\n" +
                       "- واجهة ذكية تفاعلية\n\n" +
                       "🎯 **Claude Code - مستقبل البرمجة الذكية**")
            .setPositiveButton("رائع!", null)
            .show();
    }

    // ⚡ تطبيقات واجهة SmartFabListener ⚡
    @Override
    public void onGenerateCodeRequest() {
        showCodeGenerationDialog();
    }

    @Override
    public void onDebugCodeRequest() {
        showDebugDialog();
    }

    @Override
    public void onExplainCodeRequest() {
        showExplanationDialog();
    }

    @Override
    public void onClaudeCodeRequest() {
        showProjectCreationDialog();
    }

    @Override
    public void onSmartHelpRequest(String context) {
        showAdvancedOptionsDialog();
    }

    // تطبيقات واجهة OnMessageActionListener
    @Override
    public void onCopyMessage(String message) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("Claude Code Response", message);
        clipboard.setPrimaryClip(clip);
        Toast.makeText(this, "✅ تم نسخ النص", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onShareMessage(String message) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_TEXT, message);
        startActivity(Intent.createChooser(shareIntent, "مشاركة من Claude Code"));
    }

    @Override
    public void onSaveMessage(String message) {
        // حفظ الرسالة في ملف
        String result = commandExecutor.executeCommand("انشئ ملف نصي للرسالة: " + message.substring(0, Math.min(50, message.length())));
        Toast.makeText(this, "💾 تم حفظ الرسالة", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }
}