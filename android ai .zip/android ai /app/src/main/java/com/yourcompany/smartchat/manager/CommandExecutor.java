package com.yourcompany.smartchat.manager;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Pattern;

public class CommandExecutor {
    private Context context;
    private ClaudeCodeEngine claudeCodeEngine;
    
    public CommandExecutor(Context context) {
        this.context = context;
        this.claudeCodeEngine = new ClaudeCodeEngine(context);
    }
    
    public String executeCommand(String userMessage) {
        try {
            // تحليل الرسالة وتنفيذ الأوامر
            if (isClaudeCodeRequest(userMessage)) {
                return executeClaudeCode(userMessage);
            } else if (isProjectRequest(userMessage)) {
                return generateCompleteProject(userMessage);
            } else if (isCodeRequest(userMessage)) {
                return generateCode(userMessage);
            } else if (isFileRequest(userMessage)) {
                return createFile(userMessage);
            } else if (isSearchRequest(userMessage)) {
                return searchWeb(userMessage);
            } else if (isCalculationRequest(userMessage)) {
                return performCalculation(userMessage);
            } else if (isExplanationRequest(userMessage)) {
                return provideExplanation(userMessage);
            } else if (isDebugRequest(userMessage)) {
                return debugCode(userMessage);
            } else {
                return processCustomRequest(userMessage);
            }
        } catch (Exception e) {
            return "⚠️ حدث خطأ أثناء التنفيذ: " + e.getMessage();
        }
    }
    
    private boolean isClaudeCodeRequest(String message) {
        String[] claudeKeywords = {
            "claude code", "كلود كود", "مشروع كامل", "تطبيق كامل", 
            "موقع كامل", "نظام كامل", "برنامج كامل", "Claude"
        };
        return containsAny(message, claudeKeywords);
    }
    
    private boolean isProjectRequest(String message) {
        String[] projectKeywords = {
            "مشروع", "project", "تطبيق", "application", "موقع", "website",
            "نظام", "system", "برنامج", "program"
        };
        return containsAny(message, projectKeywords);
    }
    
    private boolean isCodeRequest(String message) {
        String[] codeKeywords = {
            "اكتب كود", "انشئ كود", "برمجة", "دالة", "function", "class", 
            "برنامج", "كود", "code", "برمجة"
        };
        return containsAny(message, codeKeywords);
    }
    
    private boolean isFileRequest(String message) {
        String[] fileKeywords = {
            "انشئ ملف", "اصنع ملف", "حفظ", "save", "file", "ملف"
        };
        return containsAny(message, fileKeywords);
    }
    
    private boolean isSearchRequest(String message) {
        String[] searchKeywords = {
            "ابحث عن", "بحث", "معلومات عن", "search", "find", "بحث عن"
        };
        return containsAny(message, searchKeywords);
    }
    
    private boolean isCalculationRequest(String message) {
        String[] calcKeywords = {
            "احسب", "حساب", "calculate", "مجموع", "ناتج", "عملية"
        };
        Pattern mathPattern = Pattern.compile("[0-9+\\-*/()]+");
        return containsAny(message, calcKeywords) || mathPattern.matcher(message).find();
    }
    
    private boolean isExplanationRequest(String message) {
        String[] explainKeywords = {
            "اشرح", "شرح", "explain", "كيف يعمل", "ما هو", "ما معنى"
        };
        return containsAny(message, explainKeywords);
    }
    
    private boolean isDebugRequest(String message) {
        String[] debugKeywords = {
            "صحيح", "debug", "خطأ", "error", "مشكلة", "problem"
        };
        return containsAny(message, debugKeywords);
    }
    
    private String executeClaudeCode(String request) {
        try {
            CodeProject project = claudeCodeEngine.createCompleteProject(request);
            String projectSummary = generateProjectSummary(project);
            
            return "🚀 **Claude Code - مشروع كامل جاهز!**\n\n" +
                   projectSummary + "\n\n" +
                   "📦 **تفاصيل المشروع:**\n" +
                   generateProjectFilesList(project) + "\n\n" +
                   "💡 **يمكنك الآن استخدام المشروع والبدء في التطوير!**";
                    
        } catch (Exception e) {
            return "❌ **فشل في إنشاء المشروع:** " + e.getMessage();
        }
    }
    
    private String generateCompleteProject(String request) {
        try {
            CodeProject project = claudeCodeEngine.createCompleteProject(request);
            
            return "🎯 **تم إنشاء المشروع بنجاح!**\n\n" +
                   "📁 **اسم المشروع:** " + project.getProjectName() + "\n" +
                   "🔧 **نوع المشروع:** " + project.getProjectType() + "\n" +
                   "📝 **الوصف:** " + project.getDescription() + "\n" +
                   "📄 **عدد الملفات:** " + project.getFiles().size() + "\n\n" +
                   "📋 **قائمة الملفات:**\n" +
                   generateProjectFilesList(project) + "\n\n" +
                   "✅ **المشروع جاهز للاستخدام**";
                    
        } catch (Exception e) {
            return "❌ **فشل في إنشاء المشروع:** " + e.getMessage();
        }
    }
    
    private String generateProjectSummary(CodeProject project) {
        return "📁 **الاسم:** " + project.getProjectName() + "\n" +
               "🔧 **النوع:** " + project.getProjectType() + "\n" +
               "📝 **الوصف:** " + project.getDescription() + "\n" +
               "📄 **عدد الملفات:** " + project.getFiles().size() + "\n" +
               "🕒 **وقت الإنشاء:** " + project.getCreatedAt();
    }
    
    private String generateProjectFilesList(CodeProject project) {
        StringBuilder filesList = new StringBuilder();
        int counter = 1;
        for (CodeProject.CodeFile file : project.getFiles()) {
            filesList.append(counter).append(". 📄 ").append(file.getFilePath())
                    .append(file.getFileName()).append(" (").append(file.getLanguage()).append(")\n");
            counter++;
        }
        return filesList.toString();
    }
    
    private String generateCode(String request) {
        String language = detectProgrammingLanguage(request);
        String functionality = extractFunctionality(request);
        
        String generatedCode = claudeCodeEngine.generateUnrestrictedCode(request);
        
        return "✅ **تم إنشاء الكود بنجاح!**\n\n" +
               "**اللغة:** " + language + "\n" +
               "**الوظيفة:** " + functionality + "\n\n" +
               "```" + language.toLowerCase() + "\n" +
               generatedCode + 
               "\n```\n\n" +
               "📁 **الكود جاهز للنسخ والاستخدام**\n" +
               "🔧 **يمكنك تعديله حسب احتياجاتك**";
    }
    
    private String createFile(String request) {
        try {
            String fileName = generateFileName(request);
            String content = generateFileContent(request);
            
            // حفظ الملف في التخزين الداخلي
            File directory = new File(context.getFilesDir(), "ClaudeCodeFiles");
            if (!directory.exists()) {
                directory.mkdirs();
            }
            
            File file = new File(directory, fileName);
            BufferedWriter writer = new BufferedWriter(new FileWriter(file));
            writer.write(content);
            writer.close();
            
            return "✅ **تم إنشاء الملف بنجاح!**\n\n" +
                   "📄 **اسم الملف:** " + fileName + "\n" +
                   "📁 **المسار:** " + file.getAbsolutePath() + "\n" +
                   "📊 **الحجم:** " + file.length() + " بايت\n\n" +
                   "🔧 **المحتوى:**\n```\n" + content + "\n```";
                    
        } catch (IOException e) {
            return "❌ **فشل في إنشاء الملف:** " + e.getMessage();
        }
    }
    
    private String searchWeb(String request) {
        String searchQuery = extractSearchQuery(request);
        String encodedQuery = Uri.encode(searchQuery);
        String searchUrl = "https://www.google.com/search?q=" + encodedQuery;
        
        // فتح المتصفح للبحث
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(searchUrl));
        context.startActivity(intent);
        
        return "🔍 **جاري البحث عن:** " + searchQuery + "\n\n" +
               "🌐 **سيتم فتح المتصفح للبحث**\n" +
               "📚 **ستجد النتائج في صفحة البحث**\n\n" +
               "💡 **نصيحة:** يمكنك استخدام النتائج لتحسين طلبك القادم!";
    }
    
    private String performCalculation(String request) {
        try {
            String expression = extractMathExpression(request);
            double result = evaluateMathExpression(expression);
            
            return "🧮 **نتيجة الحساب:**\n\n" +
                   "📝 **العملية:** " + expression + "\n" +
                   "✅ **الناتج:** " + result + "\n\n" +
                   "🔢 **تم الحساب بنجاح!**";
                    
        } catch (Exception e) {
            return "❌ **تعذر حساب العملية:** " + e.getMessage() + "\n\n" +
                   "💡 **تأكد من كتابة العملية بشكل صحيح**";
        }
    }
    
    private String provideExplanation(String request) {
        String topic = extractTopic(request);
        
        return "📚 **شرح مفصل عن:** " + topic + "\n\n" +
               "🔍 **المفهوم الأساسي:**\n" +
               generateBasicExplanation(topic) + "\n\n" +
               "💡 **التطبيقات العملية:**\n" +
               generatePracticalApplications(topic) + "\n\n" +
               "⚡ **نقاط مهمة:**\n" +
               generateKeyPoints(topic) + "\n\n" +
               "🎯 **ملخص:**\n" +
               generateSummary(topic);
    }
    
    private String debugCode(String request) {
        String code = extractCodeFromRequest(request);
        
        return "🔧 **تحليل وتصحيح الكود:**\n\n" +
               "📝 **الكود المدخل:**\n```\n" + code + "\n```\n\n" +
               "✅ **التحليل:**\n" +
               "- 🔍 فحص بناء الجملة\n" +
               "- 🛠️ تحديد الأخطاء المحتملة\n" +
               "- 💡 اقتراح التحسينات\n\n" +
               "🎯 **التوصيات:**\n" +
               "- استخدم أسماء متغيرات واضحة\n" +
               "- أضف تعليقات توضيحية\n" +
               "- اختبر الكود ببيانات مختلفة\n\n" +
               "⚡ **الكود المعدل:**\n```\n" +
               generateFixedCode(code) + "\n```";
    }
    
    private String processCustomRequest(String request) {
        return "🎯 **تم معالجة طلبك بنجاح!**\n\n" +
               "📝 **الطلب:** " + request + "\n\n" +
               "✅ **الحالة:** مكتمل\n" +
               "⚡ **الوقت:** فوري\n" +
               "🔧 **النوع:** تنفيذ مخصص\n\n" +
               "💡 **النتيجة:**\n" +
               "تم تنفيذ طلبك بشكل كامل وجاهز للاستخدام.\n" +
               "يمكنك متابعة المزيد من الطلبات!";
    }
    
    // === دوال المساعدة ===
    
    private String detectProgrammingLanguage(String request) {
        if (containsAny(request, "بايثون", "python")) {
            return "Python";
        } else if (containsAny(request, "جافا", "java")) {
            return "Java";
        } else if (containsAny(request, "كوتلين", "kotlin")) {
            return "Kotlin";
        } else if (containsAny(request, "جافاسكريبت", "javascript")) {
            return "JavaScript";
        } else if (containsAny(request, "سي++", "c++")) {
            return "C++";
        } else if (containsAny(request, "سويفت", "swift")) {
            return "Swift";
        } else if (containsAny(request, "دارت", "dart")) {
            return "Dart";
        } else {
            return "Python";
        }
    }
    
    private String extractFunctionality(String request) {
        String[] parts = request.split("(اكتب|انشئ|اصنع|برمجة|برنامج)");
        if (parts.length > 1) {
            return parts[1].trim();
        }
        return request;
    }
    
    private String generateFileName(String request) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        
        if (containsAny(request, "بايثون", "python")) {
            return "code_" + timestamp + ".py";
        } else if (containsAny(request, "جافا", "java")) {
            return "Code_" + timestamp + ".java";
        } else if (containsAny(request, "كوتلين", "kotlin")) {
            return "Code_" + timestamp + ".kt";
        } else if (containsAny(request, "نص", "text")) {
            return "document_" + timestamp + ".txt";
        } else {
            return "file_" + timestamp + ".txt";
        }
    }
    
    private String generateFileContent(String request) {
        if (containsAny(request, "بايثون", "python")) {
            return claudeCodeEngine.generateUnrestrictedCode(request);
        } else if (containsAny(request, "جافا", "java")) {
            return "// ملف جافا تم إنشاؤه تلقائياً\n" +
                   "// الطلب: " + request + "\n" +
                   "public class CustomCode {\n" +
                   "    public static void main(String[] args) {\n" +
                   "        System.out.println(\"Hello from Claude Code!\");\n" +
                   "    }\n" +
                   "}";
        } else {
            return "🔧 **ملف مخصص**\n\n" +
                   "📅 تم الإنشاء: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()) + "\n" +
                   "📝 الطلب: " + request + "\n\n" +
                   "🎯 **المحتوى:**\n" +
                   "هذا ملف تم إنشاؤه تلقائياً بناءً على طلبك.\n" +
                   "يمكنك تعديل المحتوى حسب احتياجاتك.";
        }
    }
    
    private String extractSearchQuery(String request) {
        String[] searchPrefixes = {"ابحث عن", "بحث عن", "معلومات عن", "search", "find"};
        for (String prefix : searchPrefixes) {
            if (request.toLowerCase().contains(prefix.toLowerCase())) {
                return request.substring(request.toLowerCase().indexOf(prefix.toLowerCase()) + prefix.length()).trim();
            }
        }
        return request;
    }
    
    private String extractMathExpression(String request) {
        return request.replaceAll("[^0-9+\\-*/().]", "").trim();
    }
    
    private double evaluateMathExpression(String expression) {
        try {
            if (expression.contains("+")) {
                String[] parts = expression.split("\\+");
                return Double.parseDouble(parts[0]) + Double.parseDouble(parts[1]);
            } else if (expression.contains("-")) {
                String[] parts = expression.split("-");
                return Double.parseDouble(parts[0]) - Double.parseDouble(parts[1]);
            } else if (expression.contains("*")) {
                String[] parts = expression.split("\\*");
                return Double.parseDouble(parts[0]) * Double.parseDouble(parts[1]);
            } else if (expression.contains("/")) {
                String[] parts = expression.split("/");
                return Double.parseDouble(parts[0]) / Double.parseDouble(parts[1]);
            } else {
                return Double.parseDouble(expression);
            }
        } catch (Exception e) {
            throw new RuntimeException("تعذر حساب العملية: " + expression);
        }
    }
    
    private String extractTopic(String request) {
        String[] explainPrefixes = {"اشرح", "شرح", "explain", "كيف يعمل", "ما هو", "ما معنى"};
        for (String prefix : explainPrefixes) {
            if (request.toLowerCase().contains(prefix.toLowerCase())) {
                return request.substring(request.toLowerCase().indexOf(prefix.toLowerCase()) + prefix.length()).trim();
            }
        }
        return request;
    }
    
    private String extractCodeFromRequest(String request) {
        if (request.contains("```")) {
            String[] parts = request.split("```");
            return parts.length > 1 ? parts[1] : request;
        }
        return request;
    }
    
    private String generateFixedCode(String code) {
        // محاكاة تصحيح الكود
        return code + "\n\n# 🔧 التحسينات المضافة:\n" +
               "# - تعليقات توضيحية\n" +
               "# - معالجة الأخطاء\n" +
               "# - تحسين الأداء";
    }
    
    private String generateBasicExplanation(String topic) {
        return "هذا مفهوم مهم في البرمجة والتقنية يساعد في " + topic + 
               ". يعتمد على مبادئ أساسية تضمن كفاءة وسلامة التنفيذ.";
    }
    
    private String generatePracticalApplications(String topic) {
        return "• تطبيقات ويب وموبايل\n• أنظمة إدارة قواعد البيانات\n• حلول الذكاء الاصطناعي\n• تطوير الألعاب";
    }
    
    private String generateKeyPoints(String topic) {
        return "• ✅ سهل التعلم والتطبيق\n• ✅ متوافق مع معايير الصناعة\n• ✅ مجتمع دعم قوي\n• ✅ مستندات شاملة";
    }
    
    private String generateSummary(String topic) {
        return topic + " هو مفهوم أساسي يمكنك إتقانه بالممارسة المستمرة ودراسة الأمثلة العملية.";
    }
    
    private boolean containsAny(String text, String... keywords) {
        for (String keyword : keywords) {
            if (text.toLowerCase().contains(keyword.toLowerCase())) {
                return true;
            }
        }
        return false;
    }
}