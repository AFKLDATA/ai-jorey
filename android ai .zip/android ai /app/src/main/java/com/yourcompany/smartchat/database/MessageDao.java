package com.yourcompany.smartchat.database;

import androidx.room.*;
import com.yourcompany.smartchat.model.ChatMessage;

import java.util.List;

@Dao
public interface MessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    List<ChatMessage> getAllMessages();

    @Query("SELECT * FROM chat_messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    List<ChatMessage> getMessagesByConversation(String conversationId);

    @Insert
    void insertMessage(ChatMessage message);

    @Update
    void updateMessage(ChatMessage message);

    @Delete
    void deleteMessage(ChatMessage message);

    @Query("DELETE FROM chat_messages")
    void deleteAllMessages();

    @Query("DELETE FROM chat_messages WHERE conversationId = :conversationId")
    void deleteConversation(String conversationId);

    @Query("SELECT * FROM chat_messages WHERE messageType = :type ORDER BY timestamp DESC")
    List<ChatMessage> getMessagesByType(String type);

    @Query("SELECT COUNT(*) FROM chat_messages")
    int getMessageCount();

    @Query("SELECT * FROM chat_messages WHERE message LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    List<ChatMessage> searchMessages(String query);
}