package com.yourcompany.smartchat.model;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.TypeConverters;

import java.util.Date;

@Entity(tableName = "chat_messages")
public class ChatMessage {
    @PrimaryKey(autoGenerate = true)
    private long id;
    
    private String message;
    private boolean isUser;
    private Date timestamp;
    private String messageType; // TEXT, CODE, EXECUTION_RESULT, PROJECT
    private String codeLanguage;
    private boolean isExecuted;
    private String conversationId;

    public ChatMessage() {
        this.timestamp = new Date();
        this.messageType = "TEXT";
        this.conversationId = "default";
    }

    public ChatMessage(String message, boolean isUser) {
        this();
        this.message = message;
        this.isUser = isUser;
    }

    public ChatMessage(String message, boolean isUser, String messageType) {
        this(message, isUser);
        this.messageType = messageType;
    }

    public ChatMessage(String message, boolean isUser, String messageType, String codeLanguage) {
        this(message, isUser, messageType);
        this.codeLanguage = codeLanguage;
    }

    // Getters and Setters
    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    
    public boolean isUser() { return isUser; }
    public void setUser(boolean user) { isUser = user; }
    
    public Date getTimestamp() { return timestamp; }
    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }
    
    public String getMessageType() { return messageType; }
    public void setMessageType(String messageType) { this.messageType = messageType; }
    
    public String getCodeLanguage() { return codeLanguage; }
    public void setCodeLanguage(String codeLanguage) { this.codeLanguage = codeLanguage; }
    
    public boolean isExecuted() { return isExecuted; }
    public void setExecuted(boolean executed) { isExecuted = executed; }
    
    public String getConversationId() { return conversationId; }
    public void setConversationId(String conversationId) { this.conversationId = conversationId; }
}