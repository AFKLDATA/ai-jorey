package com.yourcompany.smartchat.model;

import java.util.ArrayList;
import java.util.List;

public class CodeProject {
    private String projectName;
    private List<CodeFile> files;
    private String projectType; // ANDROID, WEB, SERVER, SCRIPT, AI, DESKTOP
    private String description;
    private String createdAt;

    public CodeProject(String projectName, String projectType) {
        this.projectName = projectName;
        this.projectType = projectType;
        this.files = new ArrayList<>();
        this.createdAt = java.time.LocalDateTime.now().toString();
        this.description = "مشروع " + projectType + " تم إنشاؤه تلقائياً بواسطة Claude Code";
    }

    public CodeProject(String projectName, String projectType, String description) {
        this(projectName, projectType);
        this.description = description;
    }

    public static class CodeFile {
        private String fileName;
        private String filePath;
        private String content;
        private String language;

        public CodeFile(String fileName, String content, String language) {
            this.fileName = fileName;
            this.content = content;
            this.language = language;
            this.filePath = "/" + fileName;
        }

        public CodeFile(String fileName, String filePath, String content, String language) {
            this.fileName = fileName;
            this.filePath = filePath;
            this.content = content;
            this.language = language;
        }

        // Getters and Setters
        public String getFileName() { return fileName; }
        public void setFileName(String fileName) { this.fileName = fileName; }
        
        public String getContent() { return content; }
        public void setContent(String content) { this.content = content; }
        
        public String getLanguage() { return language; }
        public void setLanguage(String language) { this.language = language; }
        
        public String getFilePath() { return filePath; }
        public void setFilePath(String filePath) { this.filePath = filePath; }
    }

    // Getters and Setters
    public String getProjectName() { return projectName; }
    public void setProjectName(String projectName) { this.projectName = projectName; }
    
    public List<CodeFile> getFiles() { return files; }
    public void setFiles(List<CodeFile> files) { this.files = files; }
    
    public String getProjectType() { return projectType; }
    public void setProjectType(String projectType) { this.projectType = projectType; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public String getCreatedAt() { return createdAt; }
    public void setCreatedAt(String createdAt) { this.createdAt = createdAt; }
    
    public void addFile(CodeFile file) { 
        if (this.files == null) {
            this.files = new ArrayList<>();
        }
        this.files.add(file); 
    }
    
    public void removeFile(CodeFile file) { 
        if (this.files != null) {
            this.files.remove(file); 
        }
    }
    
    public int getFileCount() {
        return files != null ? files.size() : 0;
    }
}